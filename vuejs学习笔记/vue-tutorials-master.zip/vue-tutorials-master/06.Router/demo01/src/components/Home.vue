<template>
	<div>
		<h1>Home</h1>
		<p>{{msg}}</p>
	</div>
</template>

<script>
	export default {
		data: function() {
			return {
				msg: 'Hello, vue router!'
			}
		}
	}
</script>