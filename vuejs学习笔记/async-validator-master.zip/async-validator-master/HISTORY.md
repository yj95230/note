# History
----

## 1.8.0 / 2017-08-16

- validator support return promise.

## 1.7.0 / 2017-06/09

- add es
- support string patter

## 1.6.0 / 2016-03-30

- support defaultField

## 1.5.0 / 2016-02-02

- support deep merge with default messages
- support rule message of any type(exp: jsx)

## 1.4.0 / 2015-01-12

- fix first option. 
- add firstFields option.
- see tests/validator.spec.js